import { useState, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

export function useFavorites() {
  const [favorites, setFavorites] = useState<string[]>([]);

  useEffect(() => {
    (async () => {
      const data = await AsyncStorage.getItem("favorites_v1");
      if (data) setFavorites(JSON.parse(data));
    })();
  }, []);

  useEffect(() => {
    AsyncStorage.setItem("favorites_v1", JSON.stringify(favorites));
  }, [favorites]);

  const toggleFavorite = (id: string) => {
    setFavorites(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  return { favorites, toggleFavorite };
}
