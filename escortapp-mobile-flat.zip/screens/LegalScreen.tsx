import React from "react";
import { View, Text, ScrollView, Button } from "react-native";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../App";

type Props = NativeStackScreenProps<RootStackParamList, "Legal">;

export default function LegalScreen({ navigation }: Props) {
  return (
    <ScrollView style={{ flex: 1, padding: 16 }}>
      <Text style={{ fontWeight: "bold", fontSize: 20 }}>Terms of Service & Privacy Policy</Text>
      <Text style={{ marginVertical: 8 }}>
        This is a demo prototype. Do not rely on this app for real bookings or transactions.
        Always comply with local laws regarding adult services. Verify identity and meet in safe locations.
      </Text>
      <Button title="Back" onPress={() => navigation.goBack()} />
    </ScrollView>
  );
}
