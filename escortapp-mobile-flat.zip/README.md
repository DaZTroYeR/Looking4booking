# EscortApp Mobile (Expo) - Ready ZIP

This project is a ready-to-run Expo mobile app (prototype). To run:

1. Install dependencies:
   ```bash
   npm install
   ```
2. Start the Expo dev server:
   ```bash
   expo start
   ```
3. Open on device via Expo Go or run on simulator.

Backend (for full functionality):
- Run the backend scaffold (provided separately) at http://localhost:4000
- Endpoints used: GET /profiles, POST /bookings, POST /reports

Notes:
- Replace placeholder assets in /assets with your branding.
- Configure `app.json` bundle identifiers and app icons before building for stores.
