import React, { useEffect, useState } from "react";
import { View, Text, FlatList, TextInput, Button, TouchableOpacity } from "react-native";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../App";
import { getProfiles } from "../services/api";
import ProfileCard from "../components/ProfileCard";

type Props = NativeStackScreenProps<RootStackParamList, "Home">;

export default function HomeScreen({ navigation }: Props) {
  const [profiles, setProfiles] = useState<any[]>([]);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);

  const fetch = async () => {
    setLoading(true);
    try {
      const data = await getProfiles({ q: query });
      setProfiles(data);
    } catch (err) {
      console.warn("Failed to load profiles", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetch();
  }, []);

  return (
    <View style={{ flex: 1, padding: 16 }}>
      <TextInput
        placeholder="Search..."
        value={query}
        onChangeText={setQuery}
        style={{ borderWidth: 1, borderRadius: 8, padding: 8, marginBottom: 8 }}
      />
      <Button title="Search" onPress={fetch} />
      {loading && <Text>Loading...</Text>}
      <FlatList
        data={profiles}
        keyExtractor={item => String(item.id)}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => navigation.navigate("Profile", { profileId: String(item.id) })}>
            <ProfileCard profile={item} />
          </TouchableOpacity>
        )}
      />
    </View>
  );
}
