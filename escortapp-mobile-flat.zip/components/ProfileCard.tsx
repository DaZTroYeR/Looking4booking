import React from "react";
import { View, Text, Image } from "react-native";

export default function ProfileCard({ profile }: { profile: any }) {
  return (
    <View style={{ flexDirection: "row", marginVertical: 8, borderWidth: 1, borderRadius: 8, padding: 8 }}>
      <Image source={{ uri: profile.images[0] }} style={{ width: 80, height: 80, borderRadius: 8 }} />
      <View style={{ marginLeft: 8, flex: 1 }}>
        <Text style={{ fontWeight: "bold" }}>{profile.name}, {profile.age}</Text>
        <Text>{profile.city} • ${profile.hourly}/hr</Text>
        <Text numberOfLines={2}>{profile.bio}</Text>
      </View>
    </View>
  );
}
