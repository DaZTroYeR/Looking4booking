import React from "react";
import { View, Text, TextInput, Button } from "react-native";

export default function BookingForm({ name, contact, date, notes, setName, setContact, setDate, setNotes, onSubmit, loading }: any) {
  return (
    <View>
      <TextInput placeholder="Your name" value={name} onChangeText={setName} style={{ borderWidth: 1, padding: 8, marginVertical: 8, borderRadius: 8 }} />
      <TextInput placeholder="Contact" value={contact} onChangeText={setContact} style={{ borderWidth: 1, padding: 8, marginVertical: 8, borderRadius: 8 }} />
      <TextInput placeholder="Date & time" value={date} onChangeText={setDate} style={{ borderWidth: 1, padding: 8, marginVertical: 8, borderRadius: 8 }} />
      <TextInput placeholder="Notes" value={notes} onChangeText={setNotes} style={{ borderWidth: 1, padding: 8, marginVertical: 8, borderRadius: 8 }} multiline />
      <Button title={loading ? "Sending..." : "Send Booking"} onPress={onSubmit} disabled={loading} />
    </View>
  );
}
