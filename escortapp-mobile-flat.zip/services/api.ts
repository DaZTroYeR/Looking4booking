import axios from "axios";

const API_BASE = "http://localhost:4000";

export const getProfiles = async (params?: any) => {
  const res = await axios.get(`${API_BASE}/profiles`, { params });
  return res.data;
};

export const sendBookingRequest = async (payload: any) => {
  const res = await axios.post(`${API_BASE}/bookings`, payload);
  return res.data;
};

export const reportProfile = async (profileId: string, reason: string) => {
  const res = await axios.post(`${API_BASE}/reports`, { profile_id: profileId, reason });
  return res.data;
};
