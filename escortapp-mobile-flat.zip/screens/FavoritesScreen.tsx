import React, { useEffect, useState } from "react";
import { View, Text, FlatList, TouchableOpacity, Image } from "react-native";
import { useFavorites } from "../hooks/useFavorites";
import { getProfiles } from "../services/api";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../App";

type Props = NativeStackScreenProps<RootStackParamList, "Favorites">;

export default function FavoritesScreen({ navigation }: Props) {
  const { favorites } = useFavorites();
  const [profiles, setProfiles] = useState<any[]>([]);

  useEffect(() => {
    (async () => {
      const data = await getProfiles();
      setProfiles(data.filter(p => favorites.includes(String(p.id))));
    })();
  }, [favorites]);

  if (favorites.length === 0) return <Text style={{ padding: 16 }}>No favorites yet</Text>;

  return (
    <FlatList
      data={profiles}
      keyExtractor={item => String(item.id)}
      renderItem={({ item }) => (
        <TouchableOpacity onPress={() => navigation.navigate("Profile", { profileId: String(item.id) })}>
          <View style={{ flexDirection: "row", padding: 8, borderWidth: 1, borderRadius: 8, marginVertical: 4 }}>
            <Image source={{ uri: item.images[0] }} style={{ width: 80, height: 80, borderRadius: 8 }} />
            <View style={{ marginLeft: 8, flex: 1 }}>
              <Text style={{ fontWeight: "bold" }}>{item.name}, {item.age}</Text>
              <Text>{item.city} • ${item.hourly}/hr</Text>
            </View>
          </View>
        </TouchableOpacity>
      )}
    />
  );
}
