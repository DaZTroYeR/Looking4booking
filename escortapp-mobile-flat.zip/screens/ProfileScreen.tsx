import React, { useEffect, useState } from "react";
import { View, Text, Image, ScrollView, Button, Alert, TouchableOpacity } from "react-native";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../App";
import { getProfiles, reportProfile } from "../services/api";
import { useFavorites } from "../hooks/useFavorites";

type Props = NativeStackScreenProps<RootStackParamList, "Profile">;

export default function ProfileScreen({ route, navigation }: Props) {
  const { profileId } = route.params;
  const [profile, setProfile] = useState<any>(null);
  const { favorites, toggleFavorite } = useFavorites();

  useEffect(() => {
    (async () => {
      const data = await getProfiles();
      const p = data.find((x: any) => String(x.id) === String(profileId));
      if (p) setProfile(p);
    })();
  }, [profileId]);

  if (!profile) return <Text>Loading...</Text>;

  const handleReport = async () => {
    try {
      await reportProfile(profile.id, "Inappropriate content");
      Alert.alert("Report sent");
    } catch (err) {
      Alert.alert("Report failed");
    }
  };

  return (
    <ScrollView style={{ flex: 1, padding: 16 }}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        {profile.images.map((img: string, i: number) => (
          <Image key={i} source={{ uri: img }} style={{ width: 200, height: 200, borderRadius: 8, marginRight: 8 }} />
        ))}
      </ScrollView>
      <Text style={{ fontWeight: "bold", fontSize: 20, marginTop: 8 }}>
        {profile.name}, {profile.age}
      </Text>
      <Text>{profile.city} • ${profile.hourly}/hr</Text>
      <Text style={{ marginVertical: 8 }}>{profile.bio}</Text>

      <Button title="Book" onPress={() => navigation.navigate("Booking", { profileId: String(profile.id) })} />
      <Button title={favorites.includes(String(profile.id)) ? "Unfavorite" : "Add to favorites"} onPress={() => toggleFavorite(String(profile.id))} />
      <Button title="Report" color="red" onPress={handleReport} />
      <Button title="Back" onPress={() => navigation.goBack()} />
    </ScrollView>
  );
}
