import React, { useState, useEffect } from "react";
import { View, Text, TextInput, Button, Alert, ScrollView } from "react-native";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../App";
import { sendBookingRequest, getProfiles } from "../services/api";

type Props = NativeStackScreenProps<RootStackParamList, "Booking">;

export default function BookingScreen({ route, navigation }: Props) {
  const { profileId } = route.params;
  const [profile, setProfile] = useState<any>(null);
  const [name, setName] = useState("");
  const [contact, setContact] = useState("");
  const [date, setDate] = useState("");
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    (async () => {
      const data = await getProfiles();
      const p = data.find((x: any) => String(x.id) === String(profileId));
      if (p) setProfile(p);
    })();
  }, [profileId]);

  const handleSubmit = async () => {
    if (!name || !contact || !date) return Alert.alert("Please fill required fields");
    setLoading(true);
    try {
      const res = await sendBookingRequest({ profile_id: profileId, requester_name: name, contact, date, notes });
      if (res.ok) {
        Alert.alert("Booking request sent");
        navigation.goBack();
      } else {
        Alert.alert("Failed to send request", res.error || 'Error');
      }
    } catch (err) {
      Alert.alert("Failed to send request");
    } finally {
      setLoading(false);
    }
  };

  if (!profile) return <Text>Loading...</Text>;

  return (
    <ScrollView style={{ flex: 1, padding: 16 }}>
      <Text style={{ fontWeight: "bold", fontSize: 20 }}>{profile.name}</Text>
      <Text>Booking form</Text>
      <TextInput placeholder="Your name" value={name} onChangeText={setName} style={{ borderWidth: 1, padding: 8, marginVertical: 8, borderRadius: 8 }} />
      <TextInput placeholder="Contact" value={contact} onChangeText={setContact} style={{ borderWidth: 1, padding: 8, marginVertical: 8, borderRadius: 8 }} />
      <TextInput placeholder="Date & time (YYYY-MM-DD HH:MM)" value={date} onChangeText={setDate} style={{ borderWidth: 1, padding: 8, marginVertical: 8, borderRadius: 8 }} />
      <TextInput placeholder="Notes" value={notes} onChangeText={setNotes} style={{ borderWidth: 1, padding: 8, marginVertical: 8, borderRadius: 8 }} multiline />
      <Button title={loading ? "Sending..." : "Send Booking"} onPress={handleSubmit} disabled={loading} />
      <Button title="Back" onPress={() => navigation.goBack()} />
    </ScrollView>
  );
}
